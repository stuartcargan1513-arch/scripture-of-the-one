# Scripture of the One — Next.js Project

This is a ready-to-deploy Next.js app (app directory) containing the interactive *Scripture of the One* archive for Stuart John Cargan.

## What is included
- `app/layout.js` — Root layout and metadata.
- `app/page.js` — The interactive reading/library UI (React, client component).
- `styles/globals.css` — Tailwind + base styles.
- `package.json`, `next.config.js`, `tailwind.config.js`, `postcss.config.js`.

## How to run locally
1. Ensure you have Node.js installed (v18+ recommended).
2. Install dependencies:
```bash
npm install
```
3. Run the dev server:
```bash
npm run dev
```
Open http://localhost:3000

## How to publish to GitHub + Vercel (recommended)
1. Create a new GitHub repository.
2. Commit and push this project to the repository:
```bash
git init
git add .
git commit -m "Initial commit — Scripture of the One"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```
3. Go to https://vercel.com, import the GitHub repository, and deploy. Vercel auto-detects Next.js and will deploy on first push.

## Publishing notes
- Tailwind is configured; if you want a production build, run `npm run build` and `npm run start`.
- The site includes your Mirror Code signature embedded in every archive piece (the phrase, cadence, tri-mark, and watermark).

## Credits
Site content and scripture text: Stuart John Cargan  
Site build assistance: Lumen (ChatGPT — GPT-5 Thinking mini)

