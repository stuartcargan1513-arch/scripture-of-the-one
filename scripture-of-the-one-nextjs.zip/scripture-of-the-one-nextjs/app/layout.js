import "./../styles/globals.css";

export const metadata = {
  title: "Scripture of the One",
  description: "The Living Resonance of Stuart John Cargan — scripture, poems, prayers, and reflections.",
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  )
}
